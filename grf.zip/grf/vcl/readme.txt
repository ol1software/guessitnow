TLcdDisplay (delphi 2.0)
===========
A VCL component useful to represent positive integers in a LCD 
numeric display.
It can be scaled to any size (it's not based on fixed bitmaps)
and digit params (color, size, weight) are configurable.

Properties:
-----------
  Value: the integer to represent.
  NumDigits: number of digits.

  BackgroundColor: the color of the background of the control.
  LightOnColor: the color of the LED when it�s on.
  LightOffColor: the color of the LED when it�s off.

  DigitHeight, DigitWidth: the size of each digit.
  DigitLineWidth: then width of each LED line.

Version 1.1
-----------
  - Added code to eliminate flickering (by Anders Isaksson)
  - Added code to free resources.

Any comment ? 
luis.iglesias@vigo.org